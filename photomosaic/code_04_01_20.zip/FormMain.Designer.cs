﻿using System;

namespace photomosaic
{
    partial class FormMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.button_generate = new System.Windows.Forms.Button();
            this.button_demo = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.line1 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label_input_tiles_dimensions = new System.Windows.Forms.Label();
            this.radioButton_cie76 = new System.Windows.Forms.RadioButton();
            this.radioButton_cie94 = new System.Windows.Forms.RadioButton();
            this.groupBox_cie = new System.Windows.Forms.GroupBox();
            this.radioButton_rgbImproved = new System.Windows.Forms.RadioButton();
            this.radioButton_rgbEuclidean = new System.Windows.Forms.RadioButton();
            this.radioButton_cie00 = new System.Windows.Forms.RadioButton();
            this.radioButton_HSV = new System.Windows.Forms.RadioButton();
            this.groupBox_scale = new System.Windows.Forms.GroupBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.textBox_newytile = new System.Windows.Forms.TextBox();
            this.textBox_newxtile = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.textBox_ytilemult = new System.Windows.Forms.TextBox();
            this.textBox_xtilemult = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.textBox_yfinal = new System.Windows.Forms.TextBox();
            this.textBox_xfinal = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.textBox_ytile = new System.Windows.Forms.TextBox();
            this.textBox_xtile = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.textBox_y = new System.Windows.Forms.TextBox();
            this.textBox_x = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox_ymult = new System.Windows.Forms.TextBox();
            this.textBox_xmult = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox_newy = new System.Windows.Forms.TextBox();
            this.textBox_newx = new System.Windows.Forms.TextBox();
            this.groupBox_src = new System.Windows.Forms.GroupBox();
            this.label_input_dimensions = new System.Windows.Forms.Label();
            this.pictureBox_img = new System.Windows.Forms.PictureBox();
            this.button_chooseInputImage = new System.Windows.Forms.Button();
            this.textBox_inputImage = new System.Windows.Forms.TextBox();
            this.groupBox_tiles = new System.Windows.Forms.GroupBox();
            this.pictureBox_dir = new System.Windows.Forms.PictureBox();
            this.button_chooseInputTiles = new System.Windows.Forms.Button();
            this.textBox_inputTiles = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.numericUpDown_variance = new System.Windows.Forms.NumericUpDown();
            this.radioButton_useAll = new System.Windows.Forms.RadioButton();
            this.radioButton_someVariance = new System.Windows.Forms.RadioButton();
            this.radioButton_mostSimilar = new System.Windows.Forms.RadioButton();
            this.toolTip_cie76 = new System.Windows.Forms.ToolTip(this.components);
            this.toolTip_cie94 = new System.Windows.Forms.ToolTip(this.components);
            this.toolTip_colorMatchingAlgorithm = new System.Windows.Forms.ToolTip(this.components);
            this.toolTip_demo = new System.Windows.Forms.ToolTip(this.components);
            this.toolTip_variance = new System.Windows.Forms.ToolTip(this.components);
            this.groupBox_split = new System.Windows.Forms.GroupBox();
            this.comboBox_split = new System.Windows.Forms.ComboBox();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.progressBar = new System.Windows.Forms.ProgressBar();
            this.label_progress = new System.Windows.Forms.Label();
            this.radioButton_cie76fast = new System.Windows.Forms.RadioButton();
            this.groupBox_cie.SuspendLayout();
            this.groupBox_scale.SuspendLayout();
            this.groupBox_src.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_img)).BeginInit();
            this.groupBox_tiles.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_dir)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_variance)).BeginInit();
            this.groupBox_split.SuspendLayout();
            this.SuspendLayout();
            // 
            // button_generate
            // 
            this.button_generate.Enabled = false;
            this.button_generate.Location = new System.Drawing.Point(391, 664);
            this.button_generate.Name = "button_generate";
            this.button_generate.Size = new System.Drawing.Size(70, 26);
            this.button_generate.TabIndex = 16;
            this.button_generate.Text = "Generate";
            this.button_generate.UseVisualStyleBackColor = true;
            this.button_generate.Click += new System.EventHandler(this.button_generate_Click);
            // 
            // button_demo
            // 
            this.button_demo.Location = new System.Drawing.Point(308, 663);
            this.button_demo.Name = "button_demo";
            this.button_demo.Size = new System.Drawing.Size(70, 26);
            this.button_demo.TabIndex = 15;
            this.button_demo.Text = "Demo";
            this.toolTip_demo.SetToolTip(this.button_demo, "Supplies a sample image and tiles");
            this.button_demo.UseVisualStyleBackColor = true;
            this.button_demo.Click += new System.EventHandler(this.button_demo_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(12, 9);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(51, 24);
            this.label3.TabIndex = 11;
            this.label3.Text = "Input";
            // 
            // line1
            // 
            this.line1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.line1.Location = new System.Drawing.Point(16, 33);
            this.line1.Name = "line1";
            this.line1.Size = new System.Drawing.Size(430, 2);
            this.line1.TabIndex = 12;
            this.line1.Text = "label4";
            // 
            // label4
            // 
            this.label4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label4.Location = new System.Drawing.Point(16, 341);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(381, 2);
            this.label4.TabIndex = 14;
            this.label4.Text = "label4";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(12, 317);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(75, 24);
            this.label5.TabIndex = 13;
            this.label5.Text = "Options";
            // 
            // label_input_tiles_dimensions
            // 
            this.label_input_tiles_dimensions.AutoSize = true;
            this.label_input_tiles_dimensions.Location = new System.Drawing.Point(20, 195);
            this.label_input_tiles_dimensions.Name = "label_input_tiles_dimensions";
            this.label_input_tiles_dimensions.Size = new System.Drawing.Size(10, 13);
            this.label_input_tiles_dimensions.TabIndex = 19;
            this.label_input_tiles_dimensions.Text = "-";
            // 
            // radioButton_cie76
            // 
            this.radioButton_cie76.AutoSize = true;
            this.radioButton_cie76.Location = new System.Drawing.Point(7, 92);
            this.radioButton_cie76.Name = "radioButton_cie76";
            this.radioButton_cie76.Size = new System.Drawing.Size(86, 17);
            this.radioButton_cie76.TabIndex = 7;
            this.radioButton_cie76.TabStop = true;
            this.radioButton_cie76.Text = "RGB->CIE76";
            this.toolTip_cie76.SetToolTip(this.radioButton_cie76, "Fast, but less accurate");
            this.radioButton_cie76.UseVisualStyleBackColor = true;
            // 
            // radioButton_cie94
            // 
            this.radioButton_cie94.AutoSize = true;
            this.radioButton_cie94.Location = new System.Drawing.Point(6, 115);
            this.radioButton_cie94.Name = "radioButton_cie94";
            this.radioButton_cie94.Size = new System.Drawing.Size(86, 17);
            this.radioButton_cie94.TabIndex = 8;
            this.radioButton_cie94.TabStop = true;
            this.radioButton_cie94.Text = "RGB->CIE94";
            this.toolTip_cie94.SetToolTip(this.radioButton_cie94, "Slower, but more accurate");
            this.radioButton_cie94.UseVisualStyleBackColor = true;
            // 
            // groupBox_cie
            // 
            this.groupBox_cie.Controls.Add(this.radioButton_cie76fast);
            this.groupBox_cie.Controls.Add(this.radioButton_rgbImproved);
            this.groupBox_cie.Controls.Add(this.radioButton_rgbEuclidean);
            this.groupBox_cie.Controls.Add(this.radioButton_cie00);
            this.groupBox_cie.Controls.Add(this.radioButton_HSV);
            this.groupBox_cie.Controls.Add(this.radioButton_cie76);
            this.groupBox_cie.Controls.Add(this.radioButton_cie94);
            this.groupBox_cie.Location = new System.Drawing.Point(309, 357);
            this.groupBox_cie.Name = "groupBox_cie";
            this.groupBox_cie.Size = new System.Drawing.Size(153, 185);
            this.groupBox_cie.TabIndex = 23;
            this.groupBox_cie.TabStop = false;
            this.groupBox_cie.Text = "Color Matching Algorithm";
            this.toolTip_colorMatchingAlgorithm.SetToolTip(this.groupBox_cie, "Select the algorithm used when comparing input image and tile colors");
            // 
            // radioButton_rgbImproved
            // 
            this.radioButton_rgbImproved.AutoSize = true;
            this.radioButton_rgbImproved.Location = new System.Drawing.Point(7, 46);
            this.radioButton_rgbImproved.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.radioButton_rgbImproved.Name = "radioButton_rgbImproved";
            this.radioButton_rgbImproved.Size = new System.Drawing.Size(95, 17);
            this.radioButton_rgbImproved.TabIndex = 11;
            this.radioButton_rgbImproved.TabStop = true;
            this.radioButton_rgbImproved.Text = "RGB Improved";
            this.radioButton_rgbImproved.UseVisualStyleBackColor = true;
            // 
            // radioButton_rgbEuclidean
            // 
            this.radioButton_rgbEuclidean.AutoSize = true;
            this.radioButton_rgbEuclidean.Location = new System.Drawing.Point(7, 23);
            this.radioButton_rgbEuclidean.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.radioButton_rgbEuclidean.Name = "radioButton_rgbEuclidean";
            this.radioButton_rgbEuclidean.Size = new System.Drawing.Size(98, 17);
            this.radioButton_rgbEuclidean.TabIndex = 10;
            this.radioButton_rgbEuclidean.TabStop = true;
            this.radioButton_rgbEuclidean.Text = "RGB Euclidean";
            this.radioButton_rgbEuclidean.UseVisualStyleBackColor = true;
            // 
            // radioButton_cie00
            // 
            this.radioButton_cie00.AutoSize = true;
            this.radioButton_cie00.Location = new System.Drawing.Point(7, 139);
            this.radioButton_cie00.Name = "radioButton_cie00";
            this.radioButton_cie00.Size = new System.Drawing.Size(86, 17);
            this.radioButton_cie00.TabIndex = 9;
            this.radioButton_cie00.TabStop = true;
            this.radioButton_cie00.Text = "RGB->CIE00";
            this.radioButton_cie00.UseVisualStyleBackColor = true;
            // 
            // radioButton_HSV
            // 
            this.radioButton_HSV.AutoSize = true;
            this.radioButton_HSV.Location = new System.Drawing.Point(7, 68);
            this.radioButton_HSV.Name = "radioButton_HSV";
            this.radioButton_HSV.Size = new System.Drawing.Size(79, 17);
            this.radioButton_HSV.TabIndex = 6;
            this.radioButton_HSV.TabStop = true;
            this.radioButton_HSV.Text = "RGB->HSV";
            this.radioButton_HSV.UseVisualStyleBackColor = true;
            // 
            // groupBox_scale
            // 
            this.groupBox_scale.Controls.Add(this.label16);
            this.groupBox_scale.Controls.Add(this.label17);
            this.groupBox_scale.Controls.Add(this.textBox_newytile);
            this.groupBox_scale.Controls.Add(this.textBox_newxtile);
            this.groupBox_scale.Controls.Add(this.label14);
            this.groupBox_scale.Controls.Add(this.label15);
            this.groupBox_scale.Controls.Add(this.textBox_ytilemult);
            this.groupBox_scale.Controls.Add(this.textBox_xtilemult);
            this.groupBox_scale.Controls.Add(this.label13);
            this.groupBox_scale.Controls.Add(this.label12);
            this.groupBox_scale.Controls.Add(this.label11);
            this.groupBox_scale.Controls.Add(this.label7);
            this.groupBox_scale.Controls.Add(this.label6);
            this.groupBox_scale.Controls.Add(this.label10);
            this.groupBox_scale.Controls.Add(this.textBox_yfinal);
            this.groupBox_scale.Controls.Add(this.textBox_xfinal);
            this.groupBox_scale.Controls.Add(this.label9);
            this.groupBox_scale.Controls.Add(this.textBox_ytile);
            this.groupBox_scale.Controls.Add(this.textBox_xtile);
            this.groupBox_scale.Controls.Add(this.label8);
            this.groupBox_scale.Controls.Add(this.textBox_y);
            this.groupBox_scale.Controls.Add(this.textBox_x);
            this.groupBox_scale.Controls.Add(this.label2);
            this.groupBox_scale.Controls.Add(this.textBox_ymult);
            this.groupBox_scale.Controls.Add(this.textBox_xmult);
            this.groupBox_scale.Controls.Add(this.label1);
            this.groupBox_scale.Controls.Add(this.textBox_newy);
            this.groupBox_scale.Controls.Add(this.textBox_newx);
            this.groupBox_scale.Location = new System.Drawing.Point(17, 356);
            this.groupBox_scale.Name = "groupBox_scale";
            this.groupBox_scale.Size = new System.Drawing.Size(277, 283);
            this.groupBox_scale.TabIndex = 24;
            this.groupBox_scale.TabStop = false;
            this.groupBox_scale.Text = "Scale Output";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(6, 177);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(52, 13);
            this.label16.TabIndex = 27;
            this.label16.Text = "New Size";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(185, 180);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(14, 13);
            this.label17.TabIndex = 26;
            this.label17.Text = "X";
            // 
            // textBox_newytile
            // 
            this.textBox_newytile.Location = new System.Drawing.Point(205, 177);
            this.textBox_newytile.Name = "textBox_newytile";
            this.textBox_newytile.ReadOnly = true;
            this.textBox_newytile.Size = new System.Drawing.Size(61, 20);
            this.textBox_newytile.TabIndex = 25;
            // 
            // textBox_newxtile
            // 
            this.textBox_newxtile.Location = new System.Drawing.Point(118, 177);
            this.textBox_newxtile.Name = "textBox_newxtile";
            this.textBox_newxtile.ReadOnly = true;
            this.textBox_newxtile.Size = new System.Drawing.Size(61, 20);
            this.textBox_newxtile.TabIndex = 24;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(6, 151);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(71, 13);
            this.label14.TabIndex = 23;
            this.label14.Text = "Size Multiplier";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(185, 154);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(14, 13);
            this.label15.TabIndex = 22;
            this.label15.Text = "X";
            // 
            // textBox_ytilemult
            // 
            this.textBox_ytilemult.Location = new System.Drawing.Point(205, 151);
            this.textBox_ytilemult.Name = "textBox_ytilemult";
            this.textBox_ytilemult.Size = new System.Drawing.Size(61, 20);
            this.textBox_ytilemult.TabIndex = 5;
            this.textBox_ytilemult.TextChanged += new System.EventHandler(this.textBox_tileymult_TextChanged);
            // 
            // textBox_xtilemult
            // 
            this.textBox_xtilemult.Location = new System.Drawing.Point(118, 151);
            this.textBox_xtilemult.Name = "textBox_xtilemult";
            this.textBox_xtilemult.Size = new System.Drawing.Size(61, 20);
            this.textBox_xtilemult.TabIndex = 4;
            this.textBox_xtilemult.TextChanged += new System.EventHandler(this.textBox_tilexmult_TextChanged);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(6, 222);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(99, 13);
            this.label13.TabIndex = 19;
            this.label13.Text = "Output Mosaic Size";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(7, 125);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(79, 13);
            this.label12.TabIndex = 18;
            this.label12.Text = "Input Tiles Size";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(7, 76);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(52, 13);
            this.label11.TabIndex = 17;
            this.label11.Text = "New Size";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(7, 50);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(71, 13);
            this.label7.TabIndex = 16;
            this.label7.Text = "Size Multiplier";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(6, 27);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(86, 13);
            this.label6.TabIndex = 15;
            this.label6.Text = "Input Image Size";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(185, 225);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(14, 13);
            this.label10.TabIndex = 14;
            this.label10.Text = "X";
            // 
            // textBox_yfinal
            // 
            this.textBox_yfinal.Location = new System.Drawing.Point(205, 222);
            this.textBox_yfinal.Name = "textBox_yfinal";
            this.textBox_yfinal.ReadOnly = true;
            this.textBox_yfinal.Size = new System.Drawing.Size(61, 20);
            this.textBox_yfinal.TabIndex = 13;
            // 
            // textBox_xfinal
            // 
            this.textBox_xfinal.Location = new System.Drawing.Point(118, 222);
            this.textBox_xfinal.Name = "textBox_xfinal";
            this.textBox_xfinal.ReadOnly = true;
            this.textBox_xfinal.Size = new System.Drawing.Size(61, 20);
            this.textBox_xfinal.TabIndex = 12;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(186, 128);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(14, 13);
            this.label9.TabIndex = 11;
            this.label9.Text = "X";
            // 
            // textBox_ytile
            // 
            this.textBox_ytile.Location = new System.Drawing.Point(206, 125);
            this.textBox_ytile.Name = "textBox_ytile";
            this.textBox_ytile.ReadOnly = true;
            this.textBox_ytile.Size = new System.Drawing.Size(61, 20);
            this.textBox_ytile.TabIndex = 10;
            // 
            // textBox_xtile
            // 
            this.textBox_xtile.Location = new System.Drawing.Point(119, 125);
            this.textBox_xtile.Name = "textBox_xtile";
            this.textBox_xtile.ReadOnly = true;
            this.textBox_xtile.Size = new System.Drawing.Size(61, 20);
            this.textBox_xtile.TabIndex = 9;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(186, 27);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(14, 13);
            this.label8.TabIndex = 8;
            this.label8.Text = "X";
            // 
            // textBox_y
            // 
            this.textBox_y.Location = new System.Drawing.Point(206, 24);
            this.textBox_y.Name = "textBox_y";
            this.textBox_y.ReadOnly = true;
            this.textBox_y.Size = new System.Drawing.Size(61, 20);
            this.textBox_y.TabIndex = 7;
            // 
            // textBox_x
            // 
            this.textBox_x.Location = new System.Drawing.Point(119, 24);
            this.textBox_x.Name = "textBox_x";
            this.textBox_x.ReadOnly = true;
            this.textBox_x.Size = new System.Drawing.Size(61, 20);
            this.textBox_x.TabIndex = 6;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(186, 53);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(14, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "X";
            // 
            // textBox_ymult
            // 
            this.textBox_ymult.Location = new System.Drawing.Point(206, 50);
            this.textBox_ymult.Name = "textBox_ymult";
            this.textBox_ymult.Size = new System.Drawing.Size(61, 20);
            this.textBox_ymult.TabIndex = 3;
            this.textBox_ymult.TextChanged += new System.EventHandler(this.textBox_ymult_TextChanged);
            // 
            // textBox_xmult
            // 
            this.textBox_xmult.Location = new System.Drawing.Point(119, 50);
            this.textBox_xmult.Name = "textBox_xmult";
            this.textBox_xmult.Size = new System.Drawing.Size(61, 20);
            this.textBox_xmult.TabIndex = 2;
            this.textBox_xmult.TextChanged += new System.EventHandler(this.textBox_xmult_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(186, 79);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(14, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "X";
            // 
            // textBox_newy
            // 
            this.textBox_newy.Location = new System.Drawing.Point(206, 76);
            this.textBox_newy.Name = "textBox_newy";
            this.textBox_newy.ReadOnly = true;
            this.textBox_newy.Size = new System.Drawing.Size(61, 20);
            this.textBox_newy.TabIndex = 1;
            // 
            // textBox_newx
            // 
            this.textBox_newx.Location = new System.Drawing.Point(119, 76);
            this.textBox_newx.Name = "textBox_newx";
            this.textBox_newx.ReadOnly = true;
            this.textBox_newx.Size = new System.Drawing.Size(61, 20);
            this.textBox_newx.TabIndex = 0;
            // 
            // groupBox_src
            // 
            this.groupBox_src.Controls.Add(this.label_input_dimensions);
            this.groupBox_src.Controls.Add(this.pictureBox_img);
            this.groupBox_src.Controls.Add(this.button_chooseInputImage);
            this.groupBox_src.Controls.Add(this.textBox_inputImage);
            this.groupBox_src.Location = new System.Drawing.Point(17, 51);
            this.groupBox_src.Name = "groupBox_src";
            this.groupBox_src.Size = new System.Drawing.Size(215, 250);
            this.groupBox_src.TabIndex = 25;
            this.groupBox_src.TabStop = false;
            this.groupBox_src.Text = "Input Image";
            // 
            // label_input_dimensions
            // 
            this.label_input_dimensions.AutoSize = true;
            this.label_input_dimensions.Location = new System.Drawing.Point(16, 195);
            this.label_input_dimensions.Name = "label_input_dimensions";
            this.label_input_dimensions.Size = new System.Drawing.Size(10, 13);
            this.label_input_dimensions.TabIndex = 23;
            this.label_input_dimensions.Text = "-";
            // 
            // pictureBox_img
            // 
            this.pictureBox_img.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.pictureBox_img.Location = new System.Drawing.Point(6, 18);
            this.pictureBox_img.Name = "pictureBox_img";
            this.pictureBox_img.Size = new System.Drawing.Size(200, 200);
            this.pictureBox_img.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox_img.TabIndex = 22;
            this.pictureBox_img.TabStop = false;
            // 
            // button_chooseInputImage
            // 
            this.button_chooseInputImage.Location = new System.Drawing.Point(181, 224);
            this.button_chooseInputImage.Name = "button_chooseInputImage";
            this.button_chooseInputImage.Size = new System.Drawing.Size(25, 20);
            this.button_chooseInputImage.TabIndex = 21;
            this.button_chooseInputImage.Text = "...";
            this.button_chooseInputImage.UseVisualStyleBackColor = true;
            this.button_chooseInputImage.Click += new System.EventHandler(this.button_chooseInputImage_Click);
            // 
            // textBox_inputImage
            // 
            this.textBox_inputImage.Location = new System.Drawing.Point(6, 224);
            this.textBox_inputImage.Name = "textBox_inputImage";
            this.textBox_inputImage.Size = new System.Drawing.Size(177, 20);
            this.textBox_inputImage.TabIndex = 0;
            // 
            // groupBox_tiles
            // 
            this.groupBox_tiles.Controls.Add(this.label_input_tiles_dimensions);
            this.groupBox_tiles.Controls.Add(this.pictureBox_dir);
            this.groupBox_tiles.Controls.Add(this.button_chooseInputTiles);
            this.groupBox_tiles.Controls.Add(this.textBox_inputTiles);
            this.groupBox_tiles.Location = new System.Drawing.Point(247, 51);
            this.groupBox_tiles.Name = "groupBox_tiles";
            this.groupBox_tiles.Size = new System.Drawing.Size(215, 250);
            this.groupBox_tiles.TabIndex = 26;
            this.groupBox_tiles.TabStop = false;
            this.groupBox_tiles.Text = "Input Tiles";
            // 
            // pictureBox_dir
            // 
            this.pictureBox_dir.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.pictureBox_dir.Location = new System.Drawing.Point(10, 18);
            this.pictureBox_dir.Name = "pictureBox_dir";
            this.pictureBox_dir.Size = new System.Drawing.Size(200, 200);
            this.pictureBox_dir.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox_dir.TabIndex = 14;
            this.pictureBox_dir.TabStop = false;
            // 
            // button_chooseInputTiles
            // 
            this.button_chooseInputTiles.Location = new System.Drawing.Point(187, 224);
            this.button_chooseInputTiles.Name = "button_chooseInputTiles";
            this.button_chooseInputTiles.Size = new System.Drawing.Size(25, 20);
            this.button_chooseInputTiles.TabIndex = 13;
            this.button_chooseInputTiles.Text = "...";
            this.button_chooseInputTiles.UseVisualStyleBackColor = true;
            this.button_chooseInputTiles.Click += new System.EventHandler(this.button_chooseInputTiles_Click);
            // 
            // textBox_inputTiles
            // 
            this.textBox_inputTiles.Location = new System.Drawing.Point(10, 224);
            this.textBox_inputTiles.Name = "textBox_inputTiles";
            this.textBox_inputTiles.Size = new System.Drawing.Size(179, 20);
            this.textBox_inputTiles.TabIndex = 1;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.numericUpDown_variance);
            this.groupBox1.Controls.Add(this.radioButton_useAll);
            this.groupBox1.Controls.Add(this.radioButton_someVariance);
            this.groupBox1.Controls.Add(this.radioButton_mostSimilar);
            this.groupBox1.Location = new System.Drawing.Point(309, 548);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(153, 91);
            this.groupBox1.TabIndex = 27;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Matching Rule";
            // 
            // numericUpDown_variance
            // 
            this.numericUpDown_variance.Location = new System.Drawing.Point(106, 44);
            this.numericUpDown_variance.Maximum = new decimal(new int[] {
            999,
            0,
            0,
            0});
            this.numericUpDown_variance.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDown_variance.Name = "numericUpDown_variance";
            this.numericUpDown_variance.Size = new System.Drawing.Size(38, 20);
            this.numericUpDown_variance.TabIndex = 12;
            this.toolTip_variance.SetToolTip(this.numericUpDown_variance, "Instead of using the most similar tile, use the x-most similar tile");
            this.numericUpDown_variance.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // radioButton_useAll
            // 
            this.radioButton_useAll.AutoSize = true;
            this.radioButton_useAll.Enabled = false;
            this.radioButton_useAll.Location = new System.Drawing.Point(7, 68);
            this.radioButton_useAll.Name = "radioButton_useAll";
            this.radioButton_useAll.Size = new System.Drawing.Size(83, 17);
            this.radioButton_useAll.TabIndex = 13;
            this.radioButton_useAll.TabStop = true;
            this.radioButton_useAll.Text = "Use All Tiles";
            this.radioButton_useAll.UseVisualStyleBackColor = true;
            // 
            // radioButton_someVariance
            // 
            this.radioButton_someVariance.AutoSize = true;
            this.radioButton_someVariance.Location = new System.Drawing.Point(7, 44);
            this.radioButton_someVariance.Name = "radioButton_someVariance";
            this.radioButton_someVariance.Size = new System.Drawing.Size(67, 17);
            this.radioButton_someVariance.TabIndex = 11;
            this.radioButton_someVariance.TabStop = true;
            this.radioButton_someVariance.Text = "Variance";
            this.radioButton_someVariance.UseVisualStyleBackColor = true;
            // 
            // radioButton_mostSimilar
            // 
            this.radioButton_mostSimilar.AutoSize = true;
            this.radioButton_mostSimilar.Location = new System.Drawing.Point(7, 20);
            this.radioButton_mostSimilar.Name = "radioButton_mostSimilar";
            this.radioButton_mostSimilar.Size = new System.Drawing.Size(81, 17);
            this.radioButton_mostSimilar.TabIndex = 10;
            this.radioButton_mostSimilar.TabStop = true;
            this.radioButton_mostSimilar.Text = "Most Similar";
            this.radioButton_mostSimilar.UseVisualStyleBackColor = true;
            // 
            // groupBox_split
            // 
            this.groupBox_split.Controls.Add(this.comboBox_split);
            this.groupBox_split.Location = new System.Drawing.Point(16, 645);
            this.groupBox_split.Name = "groupBox_split";
            this.groupBox_split.Size = new System.Drawing.Size(150, 45);
            this.groupBox_split.TabIndex = 28;
            this.groupBox_split.TabStop = false;
            this.groupBox_split.Text = "Split";
            // 
            // comboBox_split
            // 
            this.comboBox_split.FormattingEnabled = true;
            this.comboBox_split.Items.AddRange(new object[] {
            "Do not split",
            "Split into (4) images",
            "Split into (9) images",
            "Split into (16) images",
            "Split into (25) images",
            "Split into (36) images",
            "Split into (49) images",
            "Split into (64) images",
            "Split into (81) images",
            "Split into (100) images",
            "Split into (121) images",
            "Split into (144) images",
            "Split into (169) images",
            "Split into (196) images",
            "Split into (225) images",
            "Split into (256) images",
            "Split into (289) images",
            "Split into (324) images",
            "Split into (361) images",
            "Split into (400) images",
            "Split into (441) images",
            "Split into (484) images",
            "Split into (529) images",
            "Split into (576) images",
            "Split into (625) images",
            "Split into (676) images",
            "Split into (729) images",
            "Split into (784) images",
            "Split into (841) images",
            "Split into (900) images"});
            this.comboBox_split.Location = new System.Drawing.Point(7, 18);
            this.comboBox_split.Name = "comboBox_split";
            this.comboBox_split.Size = new System.Drawing.Size(270, 21);
            this.comboBox_split.TabIndex = 14;
            // 
            // progressBar
            // 
            this.progressBar.Location = new System.Drawing.Point(15, 698);
            this.progressBar.Name = "progressBar";
            this.progressBar.Size = new System.Drawing.Size(446, 23);
            this.progressBar.TabIndex = 30;
            // 
            // label_progress
            // 
            this.label_progress.AutoSize = true;
            this.label_progress.Location = new System.Drawing.Point(19, 641);
            this.label_progress.Name = "label_progress";
            this.label_progress.Size = new System.Drawing.Size(10, 13);
            this.label_progress.TabIndex = 31;
            this.label_progress.Text = ".";
            // 
            // radioButton_cie76fast
            // 
            this.radioButton_cie76fast.AutoSize = true;
            this.radioButton_cie76fast.Location = new System.Drawing.Point(7, 162);
            this.radioButton_cie76fast.Name = "radioButton_cie76fast";
            this.radioButton_cie76fast.Size = new System.Drawing.Size(139, 17);
            this.radioButton_cie76fast.TabIndex = 12;
            this.radioButton_cie76fast.TabStop = true;
            this.radioButton_cie76fast.Text = "RGB->CIE76 Fast (beta)";
            this.radioButton_cie76fast.UseVisualStyleBackColor = true;
            // 
            // FormMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(478, 734);
            this.Controls.Add(this.label_progress);
            this.Controls.Add(this.progressBar);
            this.Controls.Add(this.button_generate);
            this.Controls.Add(this.button_demo);
            this.Controls.Add(this.groupBox_split);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.groupBox_tiles);
            this.Controls.Add(this.groupBox_src);
            this.Controls.Add(this.groupBox_scale);
            this.Controls.Add(this.groupBox_cie);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.line1);
            this.Controls.Add(this.label3);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.MaximizeBox = false;
            this.Name = "FormMain";
            this.Text = "Image Mosaic Tool";
            this.groupBox_cie.ResumeLayout(false);
            this.groupBox_cie.PerformLayout();
            this.groupBox_scale.ResumeLayout(false);
            this.groupBox_scale.PerformLayout();
            this.groupBox_src.ResumeLayout(false);
            this.groupBox_src.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_img)).EndInit();
            this.groupBox_tiles.ResumeLayout(false);
            this.groupBox_tiles.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_dir)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_variance)).EndInit();
            this.groupBox_split.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }
        #endregion
        private System.Windows.Forms.Button button_generate;
        private System.Windows.Forms.Button button_demo;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label line1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label_input_tiles_dimensions;
        private System.Windows.Forms.RadioButton radioButton_cie76;
        private System.Windows.Forms.RadioButton radioButton_cie94;
        private System.Windows.Forms.GroupBox groupBox_cie;
        private System.Windows.Forms.GroupBox groupBox_scale;
        private System.Windows.Forms.GroupBox groupBox_src;
        private System.Windows.Forms.Label label_input_dimensions;
        private System.Windows.Forms.PictureBox pictureBox_img;
        private System.Windows.Forms.Button button_chooseInputImage;
        private System.Windows.Forms.TextBox textBox_inputImage;
        private System.Windows.Forms.GroupBox groupBox_tiles;
        private System.Windows.Forms.PictureBox pictureBox_dir;
        private System.Windows.Forms.Button button_chooseInputTiles;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox textBox_newytile;
        private System.Windows.Forms.TextBox textBox_newxtile;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox textBox_ytilemult;
        private System.Windows.Forms.TextBox textBox_xtilemult;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox textBox_yfinal;
        private System.Windows.Forms.TextBox textBox_xfinal;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox textBox_ytile;
        private System.Windows.Forms.TextBox textBox_xtile;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox textBox_y;
        private System.Windows.Forms.TextBox textBox_x;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox_ymult;
        private System.Windows.Forms.TextBox textBox_xmult;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox_newy;
        private System.Windows.Forms.TextBox textBox_newx;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton radioButton_useAll;
        private System.Windows.Forms.RadioButton radioButton_someVariance;
        private System.Windows.Forms.RadioButton radioButton_mostSimilar;
        private System.Windows.Forms.ToolTip toolTip_cie76;
        private System.Windows.Forms.ToolTip toolTip_cie94;
        private System.Windows.Forms.ToolTip toolTip_colorMatchingAlgorithm;
        private System.Windows.Forms.ToolTip toolTip_demo;
        private System.Windows.Forms.NumericUpDown numericUpDown_variance;
        private System.Windows.Forms.ToolTip toolTip_variance;
        private System.Windows.Forms.GroupBox groupBox_split;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.ProgressBar progressBar;
        private System.Windows.Forms.Label label_progress;
        private System.Windows.Forms.ComboBox comboBox_split;
        public System.Windows.Forms.TextBox textBox_inputTiles;
        private System.Windows.Forms.RadioButton radioButton_HSV;
        private System.Windows.Forms.RadioButton radioButton_cie00;
        private System.Windows.Forms.RadioButton radioButton_rgbEuclidean;
        private System.Windows.Forms.RadioButton radioButton_rgbImproved;
        private System.Windows.Forms.RadioButton radioButton_cie76fast;
    }
}

