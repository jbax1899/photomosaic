﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace photomosaic
{
    public class FormMainCode
    {
        static class Global
        {
            public static string src, dir;
            public static int algorithm, matchingRule, variance, split;
            public static double xscale, yscale, xtilescale, ytilescale;
            public static double[,][] tempDistances;
            public static int bitdepthMinus;
        }
        static class Src
        {
            public static Bitmap bitmap_, bitmap;
            public static Color[,] bitmapColors;
        }
        static class Dir
        {
            public static List<Bitmap> bitmaps;
            public static List<List<Bitmap>> bitmapParts;
            public static double[][][] averageColorsRectangles;

        }
        static class Dictionaries
        {
            public static Dictionary<int[], double[]> rgb2lab = new Dictionary<int[], double[]>(new MyEqualityComparer());
        }
        public static Bitmap[] Generate(
            string src, string dir, 
            int algorithm, int matchingRule, int variance, int split,
            double xscale, double yscale, double xtilescale, double ytilescale,
            IProgress<int> progress)
        {
            //Hashtables for fast cie76
            //CreateHashtableVals();
            if (algorithm == 6)
                LoadHashtableVals();
            Global.bitdepthMinus = 16;

            //set Globals
            Global.src = src;
            Global.dir = dir;
            Global.algorithm = algorithm;
            Global.matchingRule = matchingRule;
            Global.variance = variance;
            Global.split = split;
            Global.xscale = xscale;
            Global.yscale = yscale;
            Global.xtilescale = xtilescale;
            Global.ytilescale = ytilescale;

            //load src
            int w, h;
            try
            {
                Src.bitmap_ = ConvertToBitmap(src);
                Src.bitmap = new Bitmap(Src.bitmap_,
                    new System.Drawing.Size(
                        Convert.ToInt32(Src.bitmap_.Width * xscale),
                        Convert.ToInt32(Src.bitmap_.Height * yscale)
                        ));
                w = Src.bitmap.Width;
                h = Src.bitmap.Height;

                //get colors from src
                Src.bitmapColors = new Color[w, h];
                for (int x = 0; x < w; x++)
                {
                    for (int y = 0; y < h; y++)
                    {
                        if (matchingRule == 0)
                        {
                            Src.bitmapColors[x, y] = Src.bitmap.GetPixel(x, y);
                        }
                        else
                        {
                            Src.bitmapColors[x, y] = Color.FromArgb(
                                (int)Math.Truncate((decimal)Src.bitmap.GetPixel(x, y).R / Global.variance),
                                (int)Math.Truncate((decimal)Src.bitmap.GetPixel(x, y).G / Global.variance),
                                (int)Math.Truncate((decimal)Src.bitmap.GetPixel(x, y).B / Global.variance)
                                );
                        }
                    }
                }
            }
            catch (ArgumentException e)
            {
                MessageBox.Show(e.ToString());
                return new Bitmap[0];
            }

            //load dir
            int gcd, tilex, tiley;
            try
            {
                Dir.bitmaps = new List<Bitmap>();
                Dir.bitmapParts = new List<List<Bitmap>>();
                gcd = 1;
                String[] filters = { "jpg", "jpeg", "png", "gif", "tiff", "bmp", "svg" };
                String[] dirFiles = GetFilesFrom(dir, filters, false);
                for (int i = 0; i < dirFiles.Length; i++)
                {
                    Bitmap tempBitmap = ConvertToBitmap(dirFiles[i]);
                    Dir.bitmaps.Add(
                        new Bitmap(tempBitmap,
                            new System.Drawing.Size(
                            Convert.ToInt32(Math.Floor(tempBitmap.Width * xtilescale)),
                            Convert.ToInt32(Math.Floor(tempBitmap.Height * ytilescale)))
                            ));
                }
                tilex = Dir.bitmaps[0].Width;
                tiley = Dir.bitmaps[0].Height;
                gcd = GCD(tilex, tiley);
                int count = 0;
                for (int i = 0; i < Dir.bitmaps.Count; i++)              //for every dir bitmap,
                {
                    Dir.bitmapParts.Add(new List<Bitmap>());
                    for (int ix = 0; ix < (tilex / gcd); ix++)         //splitx,
                    {
                        for (int iy = 0; iy < (tiley / gcd); iy++)      //splity,
                        {
                            Bitmap bm = new Bitmap(gcd, gcd);
                            using (Graphics gr = Graphics.FromImage(bm))
                            {
                                //public Rectangle (int x, int y, int width, int height);
                                Rectangle dest_rect = new Rectangle(0, 0, gcd, gcd);
                                Rectangle source_rect = new Rectangle(ix * gcd, iy * gcd, gcd, gcd);
                                //Draws the specified portion of the specified Image at the specified location and with the specified size.
                                gr.DrawImage(Dir.bitmaps[i], dest_rect, source_rect, GraphicsUnit.Pixel);
                                gr.Dispose();
                            }
                            Dir.bitmapParts[i].Add(bm);
                            count++;
                        }
                    }
                }
            }
            catch (ArgumentException e)
            {
                MessageBox.Show(e.ToString());
                return new Bitmap[0];
            }

            //Build dir grid
            int comparex = tilex / gcd;
            int comparey = tiley / gcd;
            int gridw, gridh;

            if (w % comparex == 0) //if tiles do not fit cleanly, cut off extra
                gridw = w / comparex;
            else
                gridw = (w / comparex) - comparex;

            if (h % comparey == 0)
                gridh = h / comparey;
            else
                gridh = (h / comparey) - comparey;

            if (Global.algorithm == 0 || Global.algorithm == 1)
            {
                //Get RGB of src pixels
                Global.tempDistances = new double[gridw * comparex, gridh * comparey][];
                for (int x = 0; x < gridw * comparex; x++)
                {
                    for (int y = 0; y < gridh * comparey; y++)
                    {
                        Global.tempDistances[x, y] = new double[] {
                        Src.bitmapColors[x, y].R,
                        Src.bitmapColors[x, y].G,
                        Src.bitmapColors[x, y].B};
                    }
                }

                //get average RGB colors from dir
                Dir.averageColorsRectangles = new double[Dir.bitmapParts.Count][][];
                int length = (tilex / gcd) * (tiley / gcd);
                for (int i = 0; i < Dir.bitmapParts.Count; i++)
                {
                    Dir.averageColorsRectangles[i] = new double[length][];
                    for (int ii = 0; ii < Dir.averageColorsRectangles[i].Length; ii++)
                    {
                        Dir.averageColorsRectangles[i][ii] = averageColor(Dir.bitmapParts[i][ii]);
                    }
                }
            }
            else if (Global.algorithm == 2)
            {
                //Get HSVs of src pixels
                Global.tempDistances = new double[gridw * comparex, gridh * comparey][];
                for (int x = 0; x < gridw * comparex; x++)
                {
                    for (int y = 0; y < gridh * comparey; y++)
                    {
                        Global.tempDistances[x, y] = rgb2hsv(new int[] {
                        Src.bitmapColors[x, y].R,
                        Src.bitmapColors[x, y].G,
                        Src.bitmapColors[x, y].B});
                    }
                }

                //get average HSV colors from dir
                Dir.averageColorsRectangles = new double[Dir.bitmapParts.Count][][];
                int length = (tilex / gcd) * (tiley / gcd);
                for (int i = 0; i < Dir.bitmapParts.Count; i++)
                {
                    Dir.averageColorsRectangles[i] = new double[length][];
                    for (int ii = 0; ii < Dir.averageColorsRectangles[i].Length; ii++)
                    {
                        Dir.averageColorsRectangles[i][ii] = averageColor(Dir.bitmapParts[i][ii]);
                    }
                }
            }
            else
            {
                //Get LABs of src pixels
                Global.tempDistances = new double[gridw * comparex, gridh * comparey][];
                for (int x = 0; x < gridw * comparex; x++)
                {
                    for (int y = 0; y < gridh * comparey; y++)
                    {
                        if (algorithm == 6)
                        {
                            int[] tempRgb = DecreaseRgbColorDepth(
                                new int[] 
                                {
                                    Src.bitmapColors[x, y].R,
                                    Src.bitmapColors[x, y].G,
                                    Src.bitmapColors[x, y].B
                                },
                                Global.bitdepthMinus);
                            double[] value;
                            if (Dictionaries.rgb2lab.TryGetValue(tempRgb, out value))
                            {
                                Global.tempDistances[x, y] = value;
                            }
                            else
                            {
                                Global.tempDistances[x, y] = null;// new double[] { 0, 0, 0 };
                                MessageBox.Show(tempRgb[0].ToString() + "," + tempRgb[1].ToString() + "," + tempRgb[2].ToString());
                            }
                        }
                        else
                        {
                            Global.tempDistances[x, y] = rgb2lab(new int[] {
                            Src.bitmapColors[x, y].R,
                            Src.bitmapColors[x, y].G,
                            Src.bitmapColors[x, y].B});
                        }
                    }
                }

                //get average LAB colors from dir
                Dir.averageColorsRectangles = new double[Dir.bitmapParts.Count][][];
                int length = (tilex / gcd) * (tiley / gcd);
                for (int i = 0; i < Dir.bitmapParts.Count; i++)
                {
                    Dir.averageColorsRectangles[i] = new double[length][];
                    for (int ii = 0; ii < Dir.averageColorsRectangles[i].Length; ii++)
                    {
                        Dir.averageColorsRectangles[i][ii] = averageColor(Dir.bitmapParts[i][ii]);
                    }
                }
            }
            
            int[,] dirGrid = new int[gridw, gridh];     //tile grid
            for (int x = 0; x < gridw; x++)             //for each tile part of src...
            {
                int prog;
                try
                {
                    prog = Convert.ToInt32((double)x * gridh / (gridw * gridh) * 100);
                }
                catch(DivideByZeroException)
                {
                    prog = 0;
                }
                progress.Report(prog);
                for (int y = 0; y < gridh; y++)
                {
                    double[,][] tempDistances = new double[comparex, comparey][];
                    double[,] closestVals = new double[comparex, comparey];
                    int counter = -1;
                    for (int ix = 0; ix < comparex; ix++)
                    {
                        for (int iy = 0; iy < comparey; iy++)
                        {
                            counter++;
                            tempDistances[ix, iy] = new double[Dir.bitmaps.Count]; //...find the lab distances between bitmappart[x] and srctile[x]
                            for (int ib = 0; ib < Dir.bitmaps.Count; ib++) 
                            {
                                if (algorithm == 0) //how similar is this pixel's color to tile[im]?
                                    tempDistances[ix, iy][ib] = rgbDistance(
                                                                    Dir.averageColorsRectangles[ib][counter],
                                                                    Global.tempDistances[(x * comparex) + ix, (y * comparey) + iy]);
                                else if (algorithm == 1)                                 
                                    tempDistances[ix, iy][ib] = improvedRgbDistance(
                                                                    Dir.averageColorsRectangles[ib][counter],
                                                                    Global.tempDistances[(x * comparex) + ix, (y * comparey) + iy]);
                                else if (algorithm == 2)
                                    tempDistances[ix, iy][ib] = hsvDistance(
                                                                    Dir.averageColorsRectangles[ib][counter],
                                                                    Global.tempDistances[(x * comparex) + ix, (y * comparey) + iy]);
                                else if (algorithm == 3 || algorithm == 6)
                                    tempDistances[ix, iy][ib] = deltaE_cie76(
                                                                    Dir.averageColorsRectangles[ib][counter],
                                                                    Global.tempDistances[(x * comparex) + ix, (y * comparey) + iy]);
                                else if (algorithm == 4)
                                    tempDistances[ix, iy][ib] = deltaE_cie94(
                                                                    Dir.averageColorsRectangles[ib][counter],
                                                                    Global.tempDistances[(x * comparex) + ix, (y * comparey) + iy]);
                                else if (algorithm == 5)
                                    tempDistances[ix, iy][ib] = deltaE_cie00(
                                                                    Dir.averageColorsRectangles[ib][counter],
                                                                    Global.tempDistances[(x * comparex) + ix, (y * comparey) + iy]);
                            }
                            double closestVal = -1;
                            int closestValID = 0;
                            for (int ib = 0; ib < Dir.bitmaps.Count; ib++)
                            {
                                if (tempDistances[ix, iy][ib] < closestVal | closestVal == -1)
                                {
                                    closestVal = tempDistances[ix, iy][ib];
                                    closestValID = ib;
                                }
                            }
                            closestVals[ix, iy] = closestValID;
                        }
                    }

                    //find average distance...
                    //https://stackoverflow.com/a/8260670
                    Dictionary<double, double> counts = new Dictionary<double, double>();
                    foreach (double val in closestVals)
                    {
                        if (counts.ContainsKey(val))
                            counts[val] = counts[val] + 1;
                        else
                            counts[val] = 1;
                    }
                    double result = double.MinValue;
                    double max = double.MinValue;
                    foreach (double key in counts.Keys)
                    {
                        if (counts[key] > max)
                        {
                            max = counts[key];
                            result = key;
                        }
                    }
                    dirGrid[x, y] = (int)result;
                }
            }

            //store tile counts
            List<int[]> tileCounts = new List<int[]>();
            for (int i = 0; i < Dir.bitmaps.Count; i++)
            {
                tileCounts.Add(new int[1]);
            }
            foreach (var num in dirGrid)
            {
                tileCounts[num][0]++;
            }
            //write to file
            using (StreamWriter outputFile = new StreamWriter("tileCounts.csv"))
            {
                for (int i = 0; i < tileCounts.Count; i++)
                {
                    outputFile.WriteLine(i.ToString() + "," + tileCounts[i][0].ToString());
                }
            }

            //create mosaic
            if (split == 0)
            {
                int tileW = Dir.bitmaps[0].Width;
                int tileH = Dir.bitmaps[0].Height;
                int outW = dirGrid.GetLength(0);
                int outH = dirGrid.GetLength(1);
                Bitmap[] outputBitmaps = new Bitmap[1];
                outputBitmaps[0] = new Bitmap(outW * tileW, outH * tileH);
                Rectangle inputRect = new Rectangle(0, 0, tileW, tileH);
                for (int x = 0; x < outW; x++)
                {
                    for (int y = 0; y < outH; y++)
                    {
                        Rectangle outputRect = new Rectangle(x * tileW, y * tileH, tileW, tileH);
                        using (Graphics grD = Graphics.FromImage(outputBitmaps[0]))
                        {
                            grD.DrawImage(Dir.bitmaps[dirGrid[x, y]], outputRect, inputRect, GraphicsUnit.Pixel);
                        }
                    }
                }
                return outputBitmaps;
            }
            else
            {
                int tileW = Dir.bitmaps[0].Width;
                int tileH = Dir.bitmaps[0].Height;
                int outW = dirGrid.GetLength(0) / split;
                int outH = dirGrid.GetLength(1) / split;

                Bitmap[] outputBitmaps = new Bitmap[split * split];

                int counter = 0;
                for (int partY = 0; partY < split; partY++)
                {
                    for (int partX = 0; partX < split; partX++)
                    {
                        Bitmap outputBitmap = new Bitmap(outW * tileW, outH * tileH);
                        Rectangle inputRect = new Rectangle(0, 0, tileW, tileH);
                        for (int x = (partX * outW); x < (outW + (partX * outW)); x++)
                        {
                            for (int y = (partY * outH); y < (outH + (partY * outH)); y++)
                            {
                                Rectangle outputRect = new Rectangle(
                                    (x - (partX * outW)) * tileW, 
                                    (y - (partY * outH)) * tileH, 
                                    tileW, 
                                    tileH);
                                using (Graphics grD = Graphics.FromImage(outputBitmap))
                                {
                                    grD.DrawImage(Dir.bitmaps[dirGrid[x, y]], outputRect, inputRect, GraphicsUnit.Pixel);
                                }
                            }
                        }
                        outputBitmaps[counter] = outputBitmap;
                        counter++;
                    }
                }
                return outputBitmaps;
            }
        }
        public static Bitmap ConvertToBitmap(string fileName)
        {
            //https://stackoverflow.com/questions/24383256/how-can-i-convert-a-jpg-file-into-a-bitmap-using-c
            Bitmap bitmap = null;
            try
            {
                if (System.IO.File.Exists(fileName))
                {
                    using (Stream bmpStream = System.IO.File.Open(fileName, System.IO.FileMode.Open))
                    {
                        Image image = Image.FromStream(bmpStream);
                        bitmap = new Bitmap(image);
                    }
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show("Error - " + ex);
            }
            return bitmap;
        }
        public static String[] GetFilesFrom(String searchFolder, String[] filters, bool isRecursive)
        {
            //https://stackoverflow.com/a/18321162
            List<String> filesFound = new List<String>();
            var searchOption = isRecursive ? SearchOption.AllDirectories : SearchOption.TopDirectoryOnly;
            foreach (var filter in filters)
            {
                try
                {
                    filesFound.AddRange(Directory.GetFiles(searchFolder, String.Format("*.{0}", filter), searchOption));
                }
                catch (DirectoryNotFoundException e)
                {
                    MessageBox.Show("Directory not found!\n" + e.ToString());
                    break;
                }
                catch (ArgumentException e)
                {
                    MessageBox.Show(e.ToString());
                    break;
                }
            }
            return filesFound.ToArray();
        }
        public static double[] averageColor(Bitmap bi)
        {
            int count = 0;
            double sumA = 0, sumB = 0, sumC = 0;
            for (int x = 0; x < bi.Width; x += 1)
            {
                for (int y = 0; y < bi.Height; y += 1)
                {
                    {
                        count++;
                        Color pixel = bi.GetPixel(x, y);
                        double[] tempAvg;
                        if (Global.variance > 0)
                        {
                            if (Global.algorithm == 0 || Global.algorithm == 1)
                            {
                                tempAvg = new double[]
                                {
                                    (double)Math.Truncate((decimal)pixel.R / Global.variance),
                                    (double)Math.Truncate((decimal)pixel.G / Global.variance),
                                    (double)Math.Truncate((decimal)pixel.B / Global.variance)
                                };
                            }
                            else if (Global.algorithm == 2)
                            {
                                tempAvg = rgb2hsv(new int[]
                                {
                                    (int)Math.Truncate((decimal)pixel.R / Global.variance),
                                    (int)Math.Truncate((decimal)pixel.G / Global.variance),
                                    (int)Math.Truncate((decimal)pixel.B / Global.variance)
                                });
                            }
                            else if (Global.algorithm == 6)
                            {
                                tempAvg = DecreaseRgbColorDepth(new int[]
                                    {
                                    (int)Math.Truncate((decimal)pixel.R / Global.variance),
                                    (int)Math.Truncate((decimal)pixel.G / Global.variance),
                                    (int)Math.Truncate((decimal)pixel.B / Global.variance)
                                    },
                                    Global.bitdepthMinus).Select(Convert.ToDouble).ToArray(); //from int[] to double[]
                            }
                            else
                            {
                                tempAvg = rgb2lab(new int[]
                                {
                                    (int)Math.Truncate((decimal)pixel.R / Global.variance),
                                    (int)Math.Truncate((decimal)pixel.G / Global.variance),
                                    (int)Math.Truncate((decimal)pixel.B / Global.variance)
                                });
                            }
                        }
                        else
                        {
                            if (Global.algorithm == 0 || Global.algorithm == 1)
                                tempAvg = new double[] { pixel.R, pixel.G, pixel.B };
                            else if (Global.algorithm == 2)
                                tempAvg = rgb2hsv(new int[] { pixel.R, pixel.G, pixel.B });
                            else
                                tempAvg = rgb2lab(new int[] { pixel.R, pixel.G, pixel.B });
                        }
                        sumA += tempAvg[0];
                        sumB += tempAvg[1];
                        sumC += tempAvg[2];
                    }
                }
            }
            return new double[] { sumA / count, sumB / count, sumC / count };
        }
        public static double[] rgb2hsv(int[] rgb)
        {
            //https://www.rapidtables.com/convert/color/rgb-to-hsv.html
            double h, s, v;
            double R_ = (double)rgb[0] / 255;
            double G_ = (double)rgb[1] / 255;
            double B_ = (double)rgb[2] / 255;
            double cMax = Math.Max(R_, Math.Max(G_, B_));
            double cMin = Math.Min(R_, Math.Min(G_, B_));
            double delta = cMax - cMin;

            //hue
            if (delta == 0)
                h = 0;
            else if (cMax == R_)
            {
                h = 60 * ((G_ - B_) / (double)delta % 6);
            }
            else if (cMax == G_)
            {
                h = 60 * ((B_ - R_) / (double)delta + 2);
            }
            else if (cMax == B_)
            {
                h = 60 * ((R_ - G_) / (double)delta + 4);
            }
            else
                h = 0;

            //saturation
            if (cMax == 0)
                s = 0;
            else
                s = delta / cMax;

            //value
            v = cMax;

            //return
            double[] hsv = new double[] { h, s, v };
            return hsv;
        }
        public static double[] rgb2lab(int[] rgb)
        {
            //http://www.brucelindbloom.com/index.html?Math.html

            double r = (double)rgb[0] / 255,
                   g = (double)rgb[1] / 255,
                   b = (double)rgb[2] / 255,
                   k = (double)24389 / 27,
                   e = (double)216 / 24389,
                   x, y, z,
                   l_, a_, b_;

            //RGB -> XYZ
            r = (r > 0.04045) ? Math.Pow((r + 0.055) / 1.055, 2.4) : r / 12.92;
            g = (g > 0.04045) ? Math.Pow((g + 0.055) / 1.055, 2.4) : g / 12.92;
            b = (b > 0.04045) ? Math.Pow((b + 0.055) / 1.055, 2.4) : b / 12.92;

            r *= 100;
            g *= 100;
            b *= 100;

            x = r * 0.4124 + g * 0.3576 + b * 0.1805;
            y = r * 0.2126 + g * 0.7152 + b * 0.0722;
            z = r * 0.0193 + g * 0.1192 + b * 0.9505;
            //old
            //x = (r * 0.4124 + g * 0.3576 + b * 0.1805) / 0.95047;
            //y = (r * 0.2126 + g * 0.7152 + b * 0.0722) / 1.00000;
            //z = (r * 0.0193 + g * 0.1192 + b * 0.9505) / 1.08883;

            //XYZ -> LAB
            x = x / 100;
            y = y / 100;
            z = z / 100;

            x = (x > e) ? Math.Pow(x, (double)1 / 3) : (k * x + 16) / 116;
            y = (y > e) ? Math.Pow(y, (double)1 / 3) : (k * y + 16) / 116;
            z = (z > e) ? Math.Pow(z, (double)1 / 3) : (k * z + 16) / 116;

            l_ = (116 * y) - 16;
            a_ = 500 * (x - y);
            b_ = 200 * (y - z);
            double[] output = { l_, a_, b_ };

            return output;
        }
        public static double rgbDistance(double[] rgb0, double[] rgb1)
        {
            //regular euclidean distance
            double r0 = rgb0[0];
            double g0 = rgb0[1];
            double b0 = rgb0[2];
            double r1 = rgb1[0];
            double g1 = rgb1[1];
            double b1 = rgb1[2];
            double distance = Math.Sqrt(Math.Pow(r1 - r0, 2) + Math.Pow(g1 - g0, 2) + Math.Pow(b1 - b0, 2));
            return distance;
        }
        public static double improvedRgbDistance(double[] rgb0, double[] rgb1)
        {
            https://www.compuphase.com/cmetric.htm
            double rmean = (rgb0[0] + rgb1[0]) / 2;
            double r = rgb0[0] - rgb1[0];
            double g = rgb0[0] - rgb1[0];
            double b = rgb0[0] - rgb1[0];
            double distance = Math.Sqrt(
                (2 + (r / 256))
                * Math.Pow(r, 2)
                + 4
                * Math.Pow(g, 2)
                + (2 + ((255 - r) / 256))
                * Math.Pow(b, 2)
                );
            return distance;
        }
        public static double hsvDistance(double[] hsv0, double[] hsv1)
        {
            double h0 = hsv0[0];
            double s0 = hsv0[1];
            double v0 = hsv0[2];
            double h1 = hsv1[0];
            double s1 = hsv1[1];
            double v1 = hsv1[2];

            double dh = Math.Min(Math.Abs(h1 - h0), 360 - Math.Abs(h1 - h0)) / 180.0;
            double ds = Math.Abs(s1 - s0);
            double dv = Math.Abs(v1 - v0) / 255.0;

            double e = Math.Sqrt(dh * dh + ds * ds + dv * dv);
            return e;
        }
        public static double deltaE_cie76(double[] labA, double[] labB)
        {
            double deltaL = labA[0] - labB[0];
            double deltaA = labA[1] - labB[1];
            double deltaB = labA[2] - labB[2];
            return Math.Sqrt((deltaL * deltaL) + (deltaA * deltaA) + (deltaB * deltaB));
        }
        public static double deltaE_cie94(double[] labA, double[] labB)
        {
            double deltaL = labA[0] - labB[0];
            double deltaA = labA[1] - labB[1];
            double deltaB = labA[2] - labB[2];
            double c1 = Math.Sqrt(labA[1] * labA[1] + labA[2] * labA[2]);
            double c2 = Math.Sqrt(labB[1] * labB[1] + labB[2] * labB[2]);
            double deltaC = c1 - c2;
            double deltaH = ((deltaA * deltaA) + (deltaB * deltaB) - (deltaC * deltaC));
            deltaH = deltaH < 0 ? 0 : Math.Sqrt(deltaH);
            double deltaLKlsl = deltaL / (1.0);
            double deltaCkcsc = deltaC / (1.0 + 0.045 * c1);
            double deltaHkhsh = deltaH / (1.0 + 0.015 * c1);
            double i = ((deltaLKlsl * deltaLKlsl) + (deltaCkcsc * deltaCkcsc) + (deltaHkhsh * deltaHkhsh));
            return i < 0 ? 0 : Math.Sqrt(i);
        }
        public static double deltaE_cie00(double[] labA, double[] labB)
        {
            //https://www.easyrgb.com/en/math.php
            double CIE_L_1 = labA[0];
            double CIE_A_1 = labA[1];
            double CIE_b_1 = labA[2];          
            double CIE_L_2 = labB[0];
            double CIE_A_2 = labB[1];
            double CIE_b_2 = labB[2];

            //L*ab->L*CH
            //double var_H = Math.Atan2(CIE_b_1, CIE_A_1);  //Quadrant by signs
            //if (var_H > 0) var_H = (var_H / Math.PI) * 180;
            //else var_H = 360 - (Math.Abs(var_H) / Math.PI) * 180;
            //double WHT_L = CIE_L_1;
            //double WHT_C = Math.Sqrt(Math.Pow(CIE_A_1, 2) + Math.Pow(CIE_b_1, 2));
            //double WHT_H = var_H;
            double WHT_L = 100;
            double WHT_C = 100;
            double WHT_H = 100;

            double xC1 = Math.Sqrt(CIE_A_1 * CIE_A_1 + CIE_b_1 * CIE_b_1);
            double xC2 = Math.Sqrt(CIE_A_2 * CIE_A_2 + CIE_b_2 * CIE_b_2);
            double xCX = (xC1 + xC2) / 2;
            double xGX = 0.5 * (1 - Math.Sqrt((Math.Pow(xCX, 7)) / ((Math.Pow(xCX, 7)) + (25 ^ 7))));
            double xNN = (1 + xGX) * CIE_A_1;
            xC1 = Math.Sqrt(xNN * xNN + CIE_b_1 * CIE_b_1);
            double xH1 = CieLab2Hue(xNN, CIE_b_1);
            xNN = (1 + xGX) * CIE_A_2;
            xC2 = Math.Sqrt(xNN * xNN + CIE_b_2 * CIE_b_2);
            double xH2 = CieLab2Hue(xNN, CIE_b_2);
            double xDL = CIE_L_2 - CIE_L_1;
            double xDC = xC2 - xC1;
            double xDH;
            if ((xC1 * xC2) == 0)
            {
                xDH = 0;
            }
            else
            {
                xNN = Math.Round(xH2 - xH1, 12);
                if (Math.Abs(xNN) <= 180)
                {
                    xDH = xH2 - xH1;
                }
                else
                {
                    if (xNN > 180) xDH = xH2 - xH1 - 360;
                    else xDH = xH2 - xH1 + 360;
                }
            }

            xDH = 2 * Math.Sqrt(xC1 * xC2) * Math.Sin((xDH / 2) * (Math.PI / 180));
            double xLX = (CIE_L_1 + CIE_L_2) / 2;
            double xCY = (xC1 + xC2) / 2;
            double xHX;
            if ((xC1 * xC2) == 0)
            {
                xHX = xH1 + xH2;
            }
            else
            {
                xNN = Math.Abs(Math.Round(xH1 - xH2, 12));
                if (xNN > 180)
                {
                    if ((xH2 + xH1) < 360) xHX = xH1 + xH2 + 360;
                    else xHX = xH1 + xH2 - 360;
                }
                else
                {
                    xHX = xH1 + xH2;
                }
                xHX /= 2;
            }
            double xTX = 1 - 0.17 * Math.Cos((xHX - 30) * (Math.PI / 180)) + 0.24
                                  * Math.Cos((2 * xHX) * (Math.PI / 180)) + 0.32
                                  * Math.Cos((3 * xHX + 6) * (Math.PI / 180)) - 0.20
                                  * Math.Cos((4 * xHX - 63) * (Math.PI / 180));
            double xPH = 30 * Math.Exp(-((xHX - 275) / 25) * ((xHX - 275) / 25));
            double xRC = 2 * Math.Sqrt(Math.Pow(xCY, 7) / (Math.Pow(xCY, 7) + (Math.Pow(25, 7))));
            double xSL = 1 + ((0.015 * ((xLX - 50) * (xLX - 50))) / Math.Sqrt(20 + ((xLX - 50) * (xLX - 50))));

            double xSC = 1 + 0.045 * xCY;
            double xSH = 1 + 0.015 * xCY * xTX;
            double xRT = -Math.Sin((2 * xPH) * (Math.PI / 180)) * xRC;
            xDL = xDL / (WHT_L * xSL);
            xDC = xDC / (WHT_C * xSC);
            xDH = xDH / (WHT_H * xSH);
            double e = Math.Sqrt(Math.Pow(xDL, 2) + Math.Pow(xDC, 2) + Math.Pow(xDH, 2) + xRT * xDC * xDH);
            
            return e;
        }
        private static double CieLab2Hue(double var_a, double var_b)
        {
           //Function returns CIE-H° value
           double var_bias = 0;
           if (var_a >= 0 && var_b == 0) return 0;
           if (var_a < 0 && var_b == 0) return 180;
           if (var_a == 0 && var_b > 0) return 90;
           if (var_a == 0 && var_b < 0) return 270;
           if (var_a > 0 && var_b > 0) var_bias = 0;
           if (var_a < 0) var_bias = 180;
           if (var_a > 0 && var_b < 0) var_bias = 360;
           return (Math.Atan(var_b / var_a) * (180 / Math.PI)) + var_bias;
        }
        private static int GCD(int a, int b)
        {
            while (a != 0 && b != 0)
            {
                if (a > b)
                    a %= b;
                else
                    b %= a;
            }

            return a == 0 ? b : a;
        }
        private static void CreateHashtableVals()
        {
            //6-bit rgb
            using (StreamWriter writer = new StreamWriter("rgbCompare.txt"))
            {
                for (int r = 0; r < 64; r++)
                {
                    for (int g = 0; g < 64; g++)
                    {
                        for (int b = 0; b < 64; b++)
                        {
                            double[] lab = rgb2lab(new int[] { r, g, b });
                            writer.WriteLine(lab[0].ToString());
                            writer.WriteLine(lab[1].ToString());
                            writer.WriteLine(lab[2].ToString());
                        }
                    }
                }
            }
        }
        private static void LoadHashtableVals()
        {
            List<double[]> labs = new List<double[]>();
            string line;
            //Read the file line by line, add to lab list
            int fileCounter = 0;
            string l = "", a = "";
            System.IO.StreamReader file = new System.IO.StreamReader("rgbCompare.txt");
            while ((line = file.ReadLine()) != null)
            {
                switch(fileCounter)
                {
                    case 0:
                        l = line;
                        fileCounter++;
                        break;
                    case 1:
                        a = line;
                        fileCounter++;
                        break;
                    case 2:
                        labs.Add(new double[] { Convert.ToDouble(l), Convert.ToDouble(a), Convert.ToDouble(line) });
                        fileCounter = 0;
                        break;
                }
            }
            file.Close();

            //add list to hashtable, clear list
            int labCounter = 0;
            for (int r = 0; r < 64; r++)
            {
                for (int g = 0; g < 64; g++)
                {
                    for (int b = 0; b < 64; b++)
                    {
                        Dictionaries.rgb2lab.Add(new int[]{ r, g, b}, labs[labCounter]);
                        labCounter++;
                    }
                }
            }
            labs.Clear();
        }
        private static int[] DecreaseRgbColorDepth(int[] rgbIn, int offset)
        {
            //https://stackoverflow.com/questions/10140322/reducing-color-depth-in-an-image-is-not-reducin-the-file-size/10140972#10140972
            int R = Math.Max(0, (rgbIn[0] + offset / 2) / offset * offset - 1);
            int G = Math.Max(0, (rgbIn[1] + offset / 2) / offset * offset - 1);
            int B = Math.Max(0, (rgbIn[2] + offset / 2) / offset * offset - 1);
            return new int[] { R, G, B };
        }
        public class MyEqualityComparer : IEqualityComparer<int[]>
        {
            public bool Equals(int[] x, int[] y)
            {
                if (x.Length != y.Length)
                {
                    return false;
                }
                for (int i = 0; i < x.Length; i++)
                {
                    if (x[i] != y[i])
                    {
                        return false;
                    }
                }
                return true;
            }
            public int GetHashCode(int[] obj)
            {
                int result = 17;
                for (int i = 0; i < obj.Length; i++)
                {
                    unchecked
                    {
                        result = result * 23 + obj[i];
                    }
                }
                return result;
                /*
                //https://stackoverflow.com/questions/3404715/c-sharp-hashcode-for-array-of-ints
                int hc = array.Length;
                for (int i = 0; i < array.Length; ++i)
                {
                    hc = unchecked(hc * 314159 + array[i]);
                }
                return hc;
                */
            }
        }
    }
}