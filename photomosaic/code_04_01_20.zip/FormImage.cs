﻿using System;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace photomosaic
{
    public partial class FormImage : Form
    {
        static class Images
        {
            public static Bitmap[] bitmaps;
            public static PictureBox[] pictureboxes;
            public static int tileW, tileH, gridLength;
            public static double scale = 1;
            public static void UpdatePictureboxes(Form form, GroupBox groupBox)
            {
                Images.scale = Math.Min((double)form.Width / (double)groupBox.Width,
                                    (double)(form.Height) / (double)groupBox.Height);
                groupBox.Width = (int)Math.Round(Images.scale * groupBox.Width);
                groupBox.Height = (int)Math.Round(Images.scale * groupBox.Height);
                tileW = (int)Math.Round((double)groupBox.Width / gridLength);
                tileH = (int)Math.Round((double)groupBox.Height / gridLength);
                int counterX = 0, counterY = 0;
                for (int i = 0; i < bitmaps.Length; i++)
                {
                    pictureboxes[i].Size = new Size(tileW, tileH);
                    pictureboxes[i].Location = new Point(tileW * counterX, tileH * counterY);
                    //picturebox snaking logic
                    if (counterX + 1 == Math.Sqrt(bitmaps.Length))
                    {
                        counterX = 0;
                        counterY++;
                    }
                    else
                    {
                        counterX++;
                    }
                }
            }
        }
        public FormImage(Bitmap[] inputBitmaps)
        {
            //Initialize
            InitializeComponent();
            Images.bitmaps = inputBitmaps;
            Images.gridLength = (int)Math.Sqrt(inputBitmaps.Length);
            this.Width = 1000;
            this.Height = 1000;
            this.Text += (
                " (" + Images.bitmaps[0].Width.ToString() + "x" + Images.bitmaps[0].Height.ToString()
                + ")(x" + Images.bitmaps.Length + ")"
                );
            
            //create as many pictureboxes as we need
            Images.pictureboxes = new PictureBox[inputBitmaps.Length];
            for (int i = 0; i < inputBitmaps.Length; i++)
            {
                Images.pictureboxes[i] = new PictureBox
                {
                    Name = "pictureBox" + i.ToString(),
                    Image = inputBitmaps[i],
                    SizeMode = PictureBoxSizeMode.Zoom,
                    BorderStyle = BorderStyle.FixedSingle
                };
                groupBox1.Controls.Add(FormImage.Images.pictureboxes[i]);
            }
            //re-draw screen
            groupBox1.Width = (int)Math.Round((double)Images.bitmaps[0].Width / Images.gridLength);
            groupBox1.Height = (int)Math.Round((double)Images.bitmaps[0].Height / Images.gridLength);
            Images.UpdatePictureboxes(this, groupBox1);
        }
        private void toolStripButton_save_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFileDialog1 = new SaveFileDialog();
            saveFileDialog1.Filter = "JPeg Image|*.jpg|Bitmap Image|*.bmp|Gif Image|*.gif|Png Image|*.png";
            saveFileDialog1.Title = "Save an Image File(s)";
            saveFileDialog1.ShowDialog();

            // If the file name is not an empty string open it for saving.
            if (saveFileDialog1.FileName != "")
            {
                System.IO.FileStream fs =
                    (System.IO.FileStream)saveFileDialog1.OpenFile();
                System.Drawing.Imaging.ImageFormat imgform;
                switch (saveFileDialog1.FilterIndex)
                {
                    case 1:
                        imgform = System.Drawing.Imaging.ImageFormat.Jpeg;
                        break;
                    case 2:
                        imgform = System.Drawing.Imaging.ImageFormat.Bmp;
                        break;
                    case 3:
                        imgform = System.Drawing.Imaging.ImageFormat.Gif;
                        break;
                    case 4:
                        imgform = System.Drawing.Imaging.ImageFormat.Png;
                        break;
                    default:
                        imgform = System.Drawing.Imaging.ImageFormat.Jpeg;
                        break;
                }
                string path = fs.Name;
                fs.Close();
                File.Delete(path);
                for (int i = 0; i < Images.bitmaps.Length; i++)
                {
                    //add counter between filename and extension
                    string pathNew = path.Remove(path.Length - (imgform.ToString().Length + 1)) + "_" + i.ToString() + "." + imgform.ToString();
                    Images.bitmaps[i].Save(pathNew, imgform);
                }
                MessageBox.Show("Images saved!");
            }
        }
        private void FormImage_ResizeEnd(Object sender, EventArgs e)
        {
            Images.UpdatePictureboxes(this, groupBox1);
        }
    }
}